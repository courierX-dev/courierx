// CourierX — ProviderCard component

const CXProviderCard = ({ name, type, status = 'connected', apiKey = 'sk_live_••••••••••••••••', isDefault = false }) => {
  const connected = status === 'connected';

  const providerCardStyles = {
    card: { background: '#fff', border: '1px solid #E2E8F0', borderRadius: 12, boxShadow: '0 1px 3px rgba(0,0,0,0.06)', padding: '16px 20px' },
    header: { display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 },
    icon: { width: 36, height: 36, borderRadius: 8, background: '#F1F5F9', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, fontWeight: 700, color: '#334155', flexShrink: 0 },
    name: { fontSize: 14, fontWeight: 600, color: '#0F172A' },
    type: { fontSize: 12, color: '#94A3B8', marginTop: 1 },
    badges: { display: 'flex', gap: 6, marginLeft: 'auto', alignItems: 'center' },
    badge: (c) => ({ fontSize: 11, fontWeight: 500, padding: '2px 8px', borderRadius: 9999, background: c.bg, color: c.color, border: `1px solid ${c.border}` }),
    keyRow: { display: 'flex', alignItems: 'center', gap: 8, background: '#F8FAFC', border: '1px solid #E2E8F0', borderRadius: 8, padding: '7px 10px', marginBottom: 12 },
    keyText: { fontFamily: "'Geist Mono', monospace", fontSize: 12, color: '#475569', flex: 1 },
    actions: { display: 'flex', gap: 8 },
    btnSm: { fontSize: 12, fontWeight: 500, padding: '5px 10px', borderRadius: 7, border: '1px solid #E2E8F0', background: '#fff', color: '#334155', cursor: 'pointer', fontFamily: 'Inter, sans-serif' },
    btnDanger: { fontSize: 12, fontWeight: 500, padding: '5px 10px', borderRadius: 7, border: '1px solid #FECACA', background: '#FEF2F2', color: '#EF4444', cursor: 'pointer', fontFamily: 'Inter, sans-serif' },
  };

  const statusStyle = connected
    ? { bg: '#ECFDF5', color: '#10B981', border: '#A7F3D0' }
    : { bg: '#FEF2F2', color: '#EF4444', border: '#FECACA' };

  return (
    <div style={providerCardStyles.card}>
      <div style={providerCardStyles.header}>
        <div style={providerCardStyles.icon}>{name[0]}</div>
        <div>
          <div style={providerCardStyles.name}>{name}</div>
          <div style={providerCardStyles.type}>{type}</div>
        </div>
        <div style={providerCardStyles.badges}>
          {isDefault && (
            <span style={providerCardStyles.badge({ bg: '#EFF6FF', color: '#2563EB', border: '#BFDBFE' })}>Default</span>
          )}
          <span style={providerCardStyles.badge(statusStyle)}>{connected ? 'Connected' : 'Error'}</span>
        </div>
      </div>
      <div style={providerCardStyles.keyRow}>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/></svg>
        <span style={providerCardStyles.keyText}>{apiKey}</span>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round" style={{ cursor: 'pointer' }}><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
      </div>
      <div style={providerCardStyles.actions}>
        <button style={providerCardStyles.btnSm}>Edit key</button>
        {!isDefault && <button style={providerCardStyles.btnSm}>Set as default</button>}
        <button style={providerCardStyles.btnDanger}>Disconnect</button>
      </div>
    </div>
  );
};

Object.assign(window, { CXProviderCard });
