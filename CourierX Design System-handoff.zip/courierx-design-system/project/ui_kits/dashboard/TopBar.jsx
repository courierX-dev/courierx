// CourierX — TopBar component

const CXTopBar = ({ title = 'Dashboard', actions }) => {
  const topBarStyles = {
    bar: { height: 56, background: '#fff', borderBottom: '1px solid #E2E8F0', display: 'flex', alignItems: 'center', padding: '0 24px', gap: 16, flexShrink: 0 },
    title: { fontSize: 15, fontWeight: 600, color: '#0F172A', flex: 1 },
    actions: { display: 'flex', alignItems: 'center', gap: 8 },
    btn: { display: 'inline-flex', alignItems: 'center', gap: 6, fontFamily: 'Inter, sans-serif', fontSize: 13, fontWeight: 500, padding: '7px 13px', borderRadius: 8, border: '1px solid #E2E8F0', background: '#fff', color: '#334155', cursor: 'pointer' },
    btnPrimary: { background: '#2563EB', color: '#fff', borderColor: '#2563EB' },
    search: { display: 'flex', alignItems: 'center', gap: 8, background: '#F8FAFC', border: '1px solid #E2E8F0', borderRadius: 8, padding: '6px 12px', fontSize: 13, color: '#94A3B8', width: 200 },
  };

  return (
    <div style={topBarStyles.bar}>
      <div style={topBarStyles.title}>{title}</div>
      <div style={topBarStyles.actions}>
        {actions || (
          <>
            <div style={topBarStyles.search}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
              Search…
            </div>
            <button style={{ ...topBarStyles.btn, ...topBarStyles.btnPrimary }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
              New campaign
            </button>
          </>
        )}
      </div>
    </div>
  );
};

Object.assign(window, { CXTopBar });
