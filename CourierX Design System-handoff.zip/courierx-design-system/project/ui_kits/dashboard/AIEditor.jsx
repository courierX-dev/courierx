// CourierX — AIEditor component (Campaign editor with AI assist)

const CXAIEditor = () => {
  const [subject, setSubject] = React.useState('');
  const [body, setBody] = React.useState('');
  const [aiSubjects, setAiSubjects] = React.useState([
    "Your May update is here — and it's faster than ever",
    "What's new at CourierX this month",
    "3 features you asked for. All shipped.",
  ]);
  const [showAI, setShowAI] = React.useState(true);

  const editorStyles = {
    wrap: { background: '#fff', border: '1px solid #E2E8F0', borderRadius: 12, boxShadow: '0 1px 3px rgba(0,0,0,0.06)', overflow: 'hidden', display: 'flex', flexDirection: 'column', height: '100%' },
    header: { padding: '14px 20px', borderBottom: '1px solid #E2E8F0', display: 'flex', alignItems: 'center', gap: 12 },
    headerTitle: { fontSize: 14, fontWeight: 600, color: '#0F172A', flex: 1 },
    body: { display: 'flex', flex: 1, minHeight: 0 },
    main: { flex: 1, padding: 20, display: 'flex', flexDirection: 'column', gap: 14, overflowY: 'auto' },
    panel: { width: 280, borderLeft: '1px solid #E2E8F0', padding: 16, background: '#FAFBFC', display: 'flex', flexDirection: 'column', gap: 12, overflowY: 'auto' },
    fieldLabel: { fontSize: 12, fontWeight: 500, color: '#334155', marginBottom: 5, display: 'block' },
    input: { fontFamily: 'Inter, sans-serif', fontSize: 14, color: '#0F172A', background: '#fff', border: '1px solid #E2E8F0', borderRadius: 8, padding: '8px 12px', width: '100%', outline: 'none' },
    textarea: { fontFamily: 'Inter, sans-serif', fontSize: 14, color: '#0F172A', background: '#fff', border: '1px solid #E2E8F0', borderRadius: 8, padding: '10px 12px', width: '100%', outline: 'none', resize: 'none', minHeight: 200, lineHeight: 1.6 },
    aiSection: { background: '#F5F3FF', border: '1px solid #DDD6FE', borderRadius: 10, padding: 14 },
    aiHeader: { display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 },
    aiLabel: { fontSize: 12, fontWeight: 600, color: '#8B5CF6' },
    aiBadge: { fontSize: 10, fontWeight: 600, padding: '2px 7px', borderRadius: 9999, background: '#8B5CF6', color: '#fff' },
    aiItem: { padding: '8px 10px', borderRadius: 7, background: '#fff', border: '1px solid #DDD6FE', marginBottom: 6, fontSize: 13, color: '#334155', cursor: 'pointer', lineHeight: 1.4, transition: 'border-color 150ms' },
    aiItemHint: { fontSize: 11, color: '#A78BFA', marginTop: 4 },
    generateBtn: { display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, fontWeight: 500, padding: '7px 12px', borderRadius: 7, border: '1px solid #DDD6FE', background: '#fff', color: '#8B5CF6', cursor: 'pointer', fontFamily: 'Inter, sans-serif', width: '100%', justifyContent: 'center' },
    sectionTitle: { fontSize: 11, fontWeight: 500, color: '#94A3B8', letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: 8 },
    selectInput: { fontFamily: 'Inter, sans-serif', fontSize: 13, color: '#0F172A', background: '#fff', border: '1px solid #E2E8F0', borderRadius: 7, padding: '7px 10px', width: '100%', outline: 'none', cursor: 'pointer' },
    footer: { padding: '12px 20px', borderTop: '1px solid #E2E8F0', display: 'flex', gap: 8, justifyContent: 'flex-end', background: '#fff' },
    btnPrimary: { fontSize: 13, fontWeight: 500, padding: '8px 16px', borderRadius: 8, border: 'none', background: '#2563EB', color: '#fff', cursor: 'pointer', fontFamily: 'Inter, sans-serif' },
    btnSecondary: { fontSize: 13, fontWeight: 500, padding: '8px 16px', borderRadius: 8, border: '1px solid #E2E8F0', background: '#fff', color: '#334155', cursor: 'pointer', fontFamily: 'Inter, sans-serif' },
  };

  return (
    <div style={editorStyles.wrap}>
      <div style={editorStyles.header}>
        <div style={editorStyles.headerTitle}>Campaign editor</div>
        <span style={{ fontSize: 11, fontWeight: 500, padding: '2px 8px', borderRadius: 9999, background: '#FFFBEB', color: '#B45309', border: '1px solid #FDE68A' }}>Draft</span>
      </div>
      <div style={editorStyles.body}>
        <div style={editorStyles.main}>
          <div>
            <label style={editorStyles.fieldLabel}>From</label>
            <input style={editorStyles.input} defaultValue="updates@courierx.io" />
          </div>
          <div>
            <label style={editorStyles.fieldLabel}>Subject line</label>
            <input
              style={editorStyles.input}
              placeholder="Write a subject line…"
              value={subject}
              onChange={e => setSubject(e.target.value)}
            />
          </div>
          <div>
            <label style={editorStyles.fieldLabel}>Preview text</label>
            <input style={editorStyles.input} placeholder="Short preview shown in inbox…" />
          </div>
          <div style={{ flex: 1 }}>
            <label style={editorStyles.fieldLabel}>Body</label>
            <textarea
              style={editorStyles.textarea}
              placeholder="Write your email content here…"
              value={body}
              onChange={e => setBody(e.target.value)}
            />
          </div>
        </div>
        {showAI && (
          <div style={editorStyles.panel}>
            <div style={editorStyles.sectionTitle}>AI assist</div>
            <div style={editorStyles.aiSection}>
              <div style={editorStyles.aiHeader}>
                <span style={editorStyles.aiBadge}>AI</span>
                <span style={editorStyles.aiLabel}>Subject suggestions</span>
              </div>
              {aiSubjects.map((s, i) => (
                <div key={i} style={editorStyles.aiItem} onClick={() => setSubject(s)}>
                  {s}
                  <div style={editorStyles.aiItemHint}>Click to use</div>
                </div>
              ))}
              <button style={editorStyles.generateBtn}>
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#8B5CF6" strokeWidth="2" strokeLinecap="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
                Regenerate
              </button>
            </div>
            <div>
              <div style={editorStyles.sectionTitle}>Send to</div>
              <select style={editorStyles.selectInput}>
                <option>All subscribers (5,204)</option>
                <option>Active only (3,820)</option>
                <option>Segment: Developers</option>
              </select>
            </div>
            <div>
              <div style={editorStyles.sectionTitle}>Provider</div>
              <select style={editorStyles.selectInput}>
                <option>SendGrid (default)</option>
                <option>Postmark</option>
                <option>Resend</option>
              </select>
            </div>
          </div>
        )}
      </div>
      <div style={editorStyles.footer}>
        <button style={editorStyles.btnSecondary}>Save draft</button>
        <button style={editorStyles.btnPrimary}>Send campaign</button>
      </div>
    </div>
  );
};

Object.assign(window, { CXAIEditor });
