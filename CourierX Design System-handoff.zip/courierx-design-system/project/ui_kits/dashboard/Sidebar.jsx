// CourierX — Sidebar component
// Shared to window for use in index.html

const CXSidebar = ({ activeItem = 'dashboard', workspace = 'Acme Corp', user = { name: 'Jane Doe', role: 'Admin' } }) => {
  const navItems = [
    { group: 'Campaigns', items: [
      { id: 'dashboard', label: 'Dashboard', icon: 'layout-dashboard' },
      { id: 'campaigns', label: 'Campaigns', icon: 'send', badge: 3 },
      { id: 'sequences', label: 'Sequences', icon: 'git-branch' },
      { id: 'editor', label: 'Campaign editor', icon: 'file-edit' },
    ]},
    { group: 'Audience', items: [
      { id: 'subscribers', label: 'Subscribers', icon: 'users' },
      { id: 'lists', label: 'Lists', icon: 'list' },
    ]},
    { group: 'Settings', items: [
      { id: 'providers', label: 'Providers', icon: 'plug', ai: false, highlight: true },
      { id: 'settings', label: 'Settings', icon: 'settings' },
    ]},
  ];

  const Icon = ({ name, size = 16, color = 'currentColor' }) => {
    const icons = {
      'layout-dashboard': <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>,
      'send': <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>,
      'git-branch': <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><line x1="6" y1="3" x2="6" y2="15"/><circle cx="18" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M18 9a9 9 0 0 1-9 9"/></svg>,
      'file-edit': <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>,
      'users': <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>,
      'list': <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>,
      'plug': <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6L6 18"/><path d="M7 17l-4 4"/><path d="M17 7l4-4"/><path d="M12 2l2 2-7 7-2-2z"/><path d="M12 22l-2-2 7-7 2 2z"/></svg>,
      'settings': <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>,
      'chevron-down': <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"/></svg>,
    };
    return icons[name] || null;
  };

  const sidebarStyles = {
    sidebar: { width: 240, background: '#0F1E3C', display: 'flex', flexDirection: 'column', height: '100%', flexShrink: 0 },
    logo: { padding: '16px 16px 12px', display: 'flex', alignItems: 'center', gap: 10, borderBottom: '1px solid rgba(255,255,255,0.07)' },
    logoMark: { width: 28, height: 28, background: '#2563EB', borderRadius: 7, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, fontWeight: 700, color: '#fff' },
    logoText: { fontSize: 15, fontWeight: 600, color: '#fff', letterSpacing: '-0.01em' },
    workspace: { margin: '8px 10px', padding: '7px 10px', borderRadius: 7, background: 'rgba(255,255,255,0.06)', display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' },
    wsDot: { width: 20, height: 20, borderRadius: 5, background: '#2563EB', fontSize: 10, fontWeight: 700, color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center' },
    wsName: { fontSize: 12, fontWeight: 500, color: '#E2E8F0', flex: 1 },
    nav: { flex: 1, padding: '4px 10px', overflowY: 'auto' },
    navGroup: { marginBottom: 16 },
    navGroupLabel: { fontSize: 10, fontWeight: 500, color: '#475569', letterSpacing: '0.06em', textTransform: 'uppercase', padding: '0 8px', marginBottom: 2, display: 'block' },
    navItem: (active, highlight) => ({ display: 'flex', alignItems: 'center', gap: 9, padding: '7px 8px', borderRadius: 6, cursor: 'pointer', marginBottom: 1, background: active ? 'rgba(37,99,235,0.2)' : 'transparent', transition: 'background 150ms' }),
    navLabel: (active, highlight) => ({ fontSize: 13, color: highlight ? '#A78BFA' : active ? '#fff' : '#94A3B8', fontWeight: active ? 500 : 400 }),
    navBadge: { marginLeft: 'auto', fontSize: 10, fontWeight: 600, background: 'rgba(37,99,235,0.3)', color: '#93C5FD', padding: '1px 6px', borderRadius: 9999 },
    bottom: { padding: 10, borderTop: '1px solid rgba(255,255,255,0.07)', display: 'flex', alignItems: 'center', gap: 9 },
    avatar: { width: 28, height: 28, borderRadius: '50%', background: '#1D4ED8', fontSize: 11, fontWeight: 600, color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
    userName: { fontSize: 12, fontWeight: 500, color: '#E2E8F0' },
    userRole: { fontSize: 11, color: '#64748B' },
  };

  return (
    <div style={sidebarStyles.sidebar}>
      <div style={sidebarStyles.logo}>
        <div style={sidebarStyles.logoMark}>C</div>
        <div style={sidebarStyles.logoText}>Courier<span style={{ color: '#2563EB' }}>X</span></div>
      </div>
      <div style={sidebarStyles.workspace}>
        <div style={sidebarStyles.wsDot}>{workspace[0]}</div>
        <div style={sidebarStyles.wsName}>{workspace}</div>
        <Icon name="chevron-down" size={12} color="#64748B" />
      </div>
      <div style={sidebarStyles.nav}>
        {navItems.map(group => (
          <div key={group.group} style={sidebarStyles.navGroup}>
            <span style={sidebarStyles.navGroupLabel}>{group.group}</span>
            {group.items.map(item => {
              const active = item.id === activeItem;
              return (
                <div key={item.id} style={sidebarStyles.navItem(active, item.highlight)}>
                  <Icon name={item.icon} size={16} color={item.highlight ? '#8B5CF6' : active ? '#93C5FD' : '#64748B'} />
                  <span style={sidebarStyles.navLabel(active, item.highlight)}>{item.label}</span>
                  {item.badge && <span style={sidebarStyles.navBadge}>{item.badge}</span>}
                </div>
              );
            })}
          </div>
        ))}
      </div>
      <div style={sidebarStyles.bottom}>
        <div style={sidebarStyles.avatar}>{user.name.split(' ').map(n => n[0]).join('')}</div>
        <div>
          <div style={sidebarStyles.userName}>{user.name}</div>
          <div style={sidebarStyles.userRole}>{user.role}</div>
        </div>
      </div>
    </div>
  );
};

Object.assign(window, { CXSidebar });
