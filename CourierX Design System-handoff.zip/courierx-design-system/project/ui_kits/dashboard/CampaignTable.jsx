// CourierX — CampaignTable component

const CXCampaignTable = ({ onSelect }) => {
  const campaigns = [
    { id: 1, name: 'May product update', date: 'May 14, 2026', status: 'delivered', sent: '2,840', opens: '41.2%', clicks: '8.7%', bounces: '0.3%' },
    { id: 2, name: 'Welcome sequence #3', date: 'May 10, 2026', status: 'sending', sent: '1,204', opens: '55.0%', clicks: '14.2%', bounces: '0.1%' },
    { id: 3, name: 'Q2 newsletter', date: 'Draft', status: 'draft', sent: '—', opens: '—', clicks: '—', bounces: '—' },
    { id: 4, name: 'Onboarding day 7', date: 'May 2, 2026', status: 'delivered', sent: '892', opens: '62.4%', clicks: '21.1%', bounces: '0.2%' },
    { id: 5, name: 'Feature announce: AI editor', date: 'Apr 28, 2026', status: 'delivered', sent: '5,120', opens: '38.8%', clicks: '11.3%', bounces: '0.4%' },
  ];

  const statusBadge = (status) => {
    const map = {
      delivered: { bg: '#ECFDF5', color: '#10B981', border: '#A7F3D0', label: 'Delivered' },
      sending:   { bg: '#EFF6FF', color: '#2563EB', border: '#BFDBFE', label: 'Sending' },
      scheduled: { bg: '#FFFBEB', color: '#B45309', border: '#FDE68A', label: 'Scheduled' },
      draft:     { bg: '#F1F5F9', color: '#475569', border: '#E2E8F0', label: 'Draft' },
      bounced:   { bg: '#FEF2F2', color: '#EF4444', border: '#FECACA', label: 'Bounced' },
    };
    const s = map[status] || map.draft;
    return (
      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 11, fontWeight: 500, padding: '2px 8px', borderRadius: 9999, background: s.bg, color: s.color, border: `1px solid ${s.border}` }}>
        {s.label}
      </span>
    );
  };

  const tableStyles = {
    wrap: { background: '#fff', border: '1px solid #E2E8F0', borderRadius: 12, boxShadow: '0 1px 3px rgba(0,0,0,0.06)', overflow: 'hidden' },
    table: { width: '100%', borderCollapse: 'collapse' },
    th: { fontSize: 11, fontWeight: 500, color: '#94A3B8', letterSpacing: '0.04em', textTransform: 'uppercase', padding: '10px 16px', textAlign: 'left', background: '#F8FAFC', borderBottom: '1px solid #E2E8F0' },
    td: { fontSize: 13, color: '#334155', padding: '11px 16px', borderBottom: '1px solid #F1F5F9' },
    name: { fontWeight: 500, color: '#0F172A', marginBottom: 1 },
    meta: { fontSize: 11, color: '#94A3B8' },
  };

  return (
    <div style={tableStyles.wrap}>
      <table style={tableStyles.table}>
        <thead>
          <tr>
            <th style={tableStyles.th}>Campaign</th>
            <th style={tableStyles.th}>Status</th>
            <th style={tableStyles.th}>Sent</th>
            <th style={tableStyles.th}>Opens</th>
            <th style={tableStyles.th}>Clicks</th>
            <th style={tableStyles.th}>Bounces</th>
          </tr>
        </thead>
        <tbody>
          {campaigns.map((c, i) => (
            <tr key={c.id} style={{ cursor: 'pointer' }} onClick={() => onSelect && onSelect(c)}>
              <td style={{ ...tableStyles.td, borderBottom: i === campaigns.length - 1 ? 'none' : '1px solid #F1F5F9' }}>
                <div style={tableStyles.name}>{c.name}</div>
                <div style={tableStyles.meta}>{c.date}</div>
              </td>
              <td style={{ ...tableStyles.td, borderBottom: i === campaigns.length - 1 ? 'none' : '1px solid #F1F5F9' }}>{statusBadge(c.status)}</td>
              <td style={{ ...tableStyles.td, borderBottom: i === campaigns.length - 1 ? 'none' : '1px solid #F1F5F9' }}>{c.sent}</td>
              <td style={{ ...tableStyles.td, borderBottom: i === campaigns.length - 1 ? 'none' : '1px solid #F1F5F9' }}>{c.opens}</td>
              <td style={{ ...tableStyles.td, borderBottom: i === campaigns.length - 1 ? 'none' : '1px solid #F1F5F9' }}>{c.clicks}</td>
              <td style={{ ...tableStyles.td, borderBottom: i === campaigns.length - 1 ? 'none' : '1px solid #F1F5F9' }}>{c.bounces}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

Object.assign(window, { CXCampaignTable });
