# CourierX Dashboard UI Kit

## Overview
High-fidelity click-through prototype of the CourierX SaaS dashboard. Built with React + Babel, no bundler required.

## Screens included
- **Dashboard** — Stats overview + recent campaigns table
- **Campaigns** — Full campaign list table
- **Campaign editor** — Composer with AI subject line suggestions
- **Providers** — Provider connection cards with API key management
- **Subscribers** — Subscriber list with status badges
- **Sequences** — Drip sequence builder (visual step view)

## Components
| File | Exports |
|------|---------|
| `Sidebar.jsx` | `CXSidebar` |
| `TopBar.jsx` | `CXTopBar` |
| `StatsCard.jsx` | `CXStatsCard` |
| `CampaignTable.jsx` | `CXCampaignTable` |
| `ProviderCard.jsx` | `CXProviderCard` |
| `AIEditor.jsx` | `CXAIEditor` |

## Usage
Open `index.html` directly in a browser. All navigation is click-through. State (active screen) persists in localStorage on refresh.

## Design notes
- Colors, type, spacing all match `colors_and_type.css` at project root
- Navy sidebar: `#0F1E3C`; Signal Blue primary: `#2563EB`; AI Purple: `#8B5CF6`
- AI-generated content is always marked with the `#8B5CF6` AI Purple accent
- Lucide Icons (stroke, 1.5px weight) used throughout via inline SVG
