// CourierX — StatsCard component

const CXStatsCard = ({ label, value, delta, deltaDir = 'up', sub }) => {
  const isUp = deltaDir === 'up';
  const deltaColor = isUp ? '#10B981' : '#F59E0B';
  const arrow = isUp ? '↑' : '↓';

  const statsCardStyles = {
    card: { background: '#fff', border: '1px solid #E2E8F0', borderRadius: 12, boxShadow: '0 1px 3px rgba(0,0,0,0.06)', padding: '16px 20px', flex: 1 },
    label: { fontSize: 12, color: '#64748B', fontWeight: 500, marginBottom: 6 },
    value: { fontSize: 28, fontWeight: 600, color: '#0F172A', letterSpacing: '-0.02em', lineHeight: 1.1 },
    delta: { fontSize: 12, color: deltaColor, fontWeight: 500, marginTop: 4 },
    sub: { fontSize: 12, color: '#94A3B8', marginTop: 2 },
  };

  return (
    <div style={statsCardStyles.card}>
      <div style={statsCardStyles.label}>{label}</div>
      <div style={statsCardStyles.value}>{value}</div>
      {delta && <div style={statsCardStyles.delta}>{arrow} {delta}</div>}
      {sub && <div style={statsCardStyles.sub}>{sub}</div>}
    </div>
  );
};

Object.assign(window, { CXStatsCard });
