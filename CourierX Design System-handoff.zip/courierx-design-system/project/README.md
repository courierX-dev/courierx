# CourierX Design System

## Overview

**CourierX** is an AI-native email infrastructure platform for developers and product teams. It lets users plug in any email provider and any AI, then send transactional and marketing emails from a single platform — without vendor lock-in or branding taxes.

**Stack:** Next.js frontend, Node.js/TypeScript backend, Supabase.

**Sources:** No external codebase or Figma link was provided. This design system was constructed from the brand brief and design direction provided by the product team.

---

## Products / Surfaces

1. **SaaS Dashboard** — The primary web app. Includes campaign analytics, a campaign editor with AI assistance, provider settings, subscriber/list management, a sequence builder, and a project workspace switcher.
2. *(Future)* Docs site, marketing website — not yet scoped.

---

## CONTENT FUNDAMENTALS

### Voice & Tone
- **Professional but approachable.** CourierX speaks to technical buyers and solo developers. Copy is precise, never fluffy.
- **Direct and action-oriented.** Favor imperative verbs: "Connect your provider," "Send your first campaign," "Review AI suggestions."
- **No marketing fluff.** Avoid adjectives like "powerful," "seamless," or "beautiful." Let capability speak.
- **Developer-empathetic.** Uses technical terminology naturally (API keys, webhooks, deliverability, DMARC). Never oversimplifies.
- **Honest about AI.** AI-generated content is always clearly labeled with purple (#8B5CF6) and an explicit "AI" badge. No hiding the assist.

### Casing
- **Sentence case everywhere** — headings, labels, buttons, nav items. Never title case except for proper nouns.
- **Acronyms stay caps:** API, AI, SMTP, DMARC, DNS, HTTP.

### Person
- **Second person ("you/your")** in UI copy: "Your campaigns," "Connect your provider."
- **First person avoided** in UI — no "My Campaigns." Exception: user-owned workspace names.

### Emoji
- **No emoji in the UI.** Status is communicated via color-coded badges and icons only.
- **No emoji in headings, navigation, or buttons.**

### Example Copy Patterns
- Empty state: "No campaigns yet. Create your first campaign to get started."
- Error: "Failed to send. Check your provider credentials and try again."
- AI badge label: "AI-suggested subject line"
- Button labels: "Send campaign", "Add provider", "Create sequence", "Invite member"
- Success toast: "Campaign sent to 1,204 subscribers."

---

## VISUAL FOUNDATIONS

### Color
- **Background:** `#F8FAFC` base canvas; `#FFFFFF` card surfaces layered on top. Depth via layering only.
- **Primary:** `#2563EB` Signal Blue — CTAs, active states, links, focus rings.
- **Navy:** `#0F1E3C` — Sidebar background, dark headers. High-contrast anchor.
- **AI Purple:** `#8B5CF6` — Exclusively for AI-generated content highlights, badges, and accents.
- **Success:** `#10B981` | **Warning:** `#F59E0B` | **Danger:** `#EF4444`
- **Neutrals:** Slate scale from Tailwind (slate-100 through slate-900).

### Typography
- **Font:** Inter (primary), with Geist Mono for code/API keys.
- **Scale:** 12 / 13 / 14 / 16 / 18 / 20 / 24 / 30 / 36px.
- **Weight:** 400 regular, 500 medium, 600 semibold. No bold (700) in UI — semibold is the max.
- **Line height:** 1.5 for body, 1.2 for display headings.
- **Letter spacing:** -0.01em on headings 20px+; normal on body.

### Spacing
- **4px base unit.** Scale: 4, 8, 12, 16, 20, 24, 32, 40, 48, 64px.
- **Layout:** Fixed sidebar (240px); content area fluid. 24px gutters.

### Borders & Radius
- **Radius:** 8px for inputs/buttons/chips; 12px for cards and panels.
- **Border:** `1px solid` using `#E2E8F0` (slate-200). Hairlines at `0.5px` on dividers.
- **No heavy drop shadows.** Only `box-shadow: 0 1px 3px rgba(0,0,0,0.06)` for cards.

### Backgrounds & Surfaces
- No gradients. No textures. No images behind UI.
- White cards on `#F8FAFC` body — that's the only layering system.
- Sidebar is `#0F1E3C` (Navy) with white text.

### Animation
- Minimal. Transitions at `150ms ease` for hover states, `200ms ease` for panel open/close.
- No bounces, springs, or decorative motion. Functional only.

### Hover & Press States
- **Hover:** slightly darker background (e.g. slate-100 → slate-200 for ghost items; blue-600 → blue-700 for primary buttons).
- **Press:** 2px scale-down (`transform: scale(0.98)`) on buttons only.
- **Links:** underline on hover, no underline at rest.

### Cards
- Background: `#FFFFFF`; radius: `12px`; border: `1px solid #E2E8F0`; shadow: `0 1px 3px rgba(0,0,0,0.06)`.

### Iconography
- See ICONOGRAPHY section below.

---

## ICONOGRAPHY

- **Icon set:** Lucide Icons (CDN: `https://unpkg.com/lucide@latest`). Stroke-based, 1.5px stroke weight, rounded linecaps. 16px / 20px / 24px sizes.
- **Usage:** Icons are decorative support only — always paired with a text label except in icon-only buttons (which require a tooltip).
- **Color:** Inherit from text color (slate-500 for muted, slate-900 for active, #2563EB for primary actions, #8B5CF6 for AI elements).
- **No PNG icons or emoji in the UI.**
- **Logo:** Text-based wordmark "CourierX" — Inter 600, with the "X" in Signal Blue (#2563EB). No logomark/icon version defined in brief; placeholder square used in sidebar.

---

## FILE INDEX

```
README.md                      — This file
SKILL.md                       — Agent skill definition
colors_and_type.css            — All CSS custom properties (colors, type, spacing)
assets/                        — Logos and brand assets
preview/                       — Design system preview cards (registered in Design System tab)
  colors-brand.html
  colors-neutrals.html
  colors-semantic.html
  type-scale.html
  type-specimens.html
  spacing-tokens.html
  spacing-radius-shadow.html
  components-buttons.html
  components-inputs.html
  components-badges.html
  components-cards.html
  components-sidebar.html
  components-tables.html
ui_kits/
  dashboard/
    README.md
    index.html               — Main dashboard prototype
    Sidebar.jsx
    TopBar.jsx
    StatsCard.jsx
    CampaignTable.jsx
    ProviderCard.jsx
    AIEditor.jsx
```
